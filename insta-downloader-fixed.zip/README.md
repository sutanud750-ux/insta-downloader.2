# QuickSave - Instagram Downloader

🚀 Fast & Free Instagram Downloader (Educational Project)

⚠️ Works only for **public posts/reels** that you **own** or have permission to download.  
Does **not** work for private content.

## Deploy on Vercel (Free)
1. Upload this folder to a GitHub repo.
2. Go to [vercel.com](https://vercel.com), connect GitHub, import repo.
3. Click **Deploy** → Done 🎉
